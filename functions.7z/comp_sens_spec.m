

function [svmSensitivity,svmSpecificity] = comp_sens_spec(y_true,y_pred,neg_pos_class_labels)

numberOfClassLabelsInTarget = length(neg_pos_class_labels);
targets = numVectorToMatrixFcn(y_true,numberOfClassLabelsInTarget);
outputs = numVectorToMatrixFcn(y_pred, numberOfClassLabelsInTarget);
[~,numofsamplesInEachCMpartition,~,~] = confusion(targets,outputs);
numericPositiveClassLabel = neg_pos_class_labels(2);
numericNegativeClassLabel = neg_pos_class_labels(1);

TP = numofsamplesInEachCMpartition(numericPositiveClassLabel,numericPositiveClassLabel); 
TN = numofsamplesInEachCMpartition(numericNegativeClassLabel,numericNegativeClassLabel); 
originalPositiveClassMembers = length(find(y_true == numericPositiveClassLabel));
originalNegativeClassMembers = length(find(y_true == numericNegativeClassLabel));

% SENSITIVITY AND SPECIFICITY
if TP ~= 0
    svmSensitivity = (TP/originalPositiveClassMembers)*100;
else
    svmSensitivity = 0;
end

if TN ~= 0
    svmSpecificity = (TN/originalNegativeClassMembers)*100;
else
    svmSpecificity = 0;
end  
end