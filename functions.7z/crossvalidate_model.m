
% cross-validate models and return relevant metrics

function [validation_predictions, validation_scores,accuracy] = crossvalidate_model(trained_model, kfold)
cv_model = crossval(trained_model,'KFold',kfold);
[validation_predictions, validation_scores] = kfoldPredict(cv_model);
validation_accuracy = 1 - kfoldLoss(cv_model, 'LossFun', 'ClassifError');
accuracy = validation_accuracy*100;
end