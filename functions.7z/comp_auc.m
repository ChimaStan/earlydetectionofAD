% Calculating area under the ROC curve plotting ROC function
function [FPR,TPR,threshold,auc] = comp_auc(y_true, model_scores,numeric_pos_class_label)
[FPR,TPR,threshold,auc] = perfcurve(y_true,model_scores(:,2),numeric_pos_class_label);
end