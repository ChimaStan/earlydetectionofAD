% USE ONLY FOR VERY HIGH MEMORY DEMANDING CONBINATION SCENERIOS
% Combination generation function: for generating the different combinations of the elements of a row/col vector 
% THIS VERSION ACCEPTS SPECIFICATION OF THE min & max LIMITS FOR THE
% COMBINATION. THIS VERSION1 USES A SINGLE CELL TO HOLD ALL CATEGORIES OF THE
% COMBINATIONS AND RETURNS THE THE CELL AT THE END EXECUTION
function possibleComb = gen_lists_of_panel_categs(inputVector,minCateg,maxCateg)  
    totalNumOfCateg = maxCateg-minCateg+1;
    possibleComb = cell(1,totalNumOfCateg);
    k = 1;
    for categ = minCateg:maxCateg
        % monitoring progress of the combinatorial function and memory status
        fprintf('Combinatorial category being processed is: %d\n',categ);
        disp(datetime('now'));
%         [userview, systemview] = memory;
%         disp('Current staus of memory is:')
%         fprintf('\n');
%         disp(userview);
%         disp('VirtualAddressSpace:');
%         disp(systemview.VirtualAddressSpace);
%         disp('SystemMemory:');
%         disp(systemview.SystemMemory);
%         disp('PhysicalMemory:');
%         disp(systemview.PhysicalMemory);
%         fprintf('\n');
        % end of monitor
        combinations = nchoosek(inputVector,categ);

        possibleComb(k) = {combinations};
        fprintf('Combinatorial category that just finished processing is: %d\n',categ);
        disp(datetime('now'));
        k = k + 1;
    end
end