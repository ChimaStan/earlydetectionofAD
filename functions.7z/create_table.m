% create new table for collecting a model's performance metrics
function newTable = create_table(num_rows)
sz = [num_rows, 5];
varTypes = {'string','double','double','double','double'};
varNames = {'biomarkers','accuracy','sensitivity','specificity','AUC'};
newTable = table('Size',sz,'VariableTypes',varTypes,'VariableNames',varNames);
end