
% write panel performance results to performance report table
function ResultTable = write_perf_to_table(table_to_write_to,panel,row_to_write_to,accuracy,sensitivity,specificity,auc)
    panel = {strjoin(panel)};
    table_to_write_to.biomarkers(row_to_write_to) = panel;
    table_to_write_to.accuracy(row_to_write_to) = accuracy;
    table_to_write_to.sensitivity(row_to_write_to) = sensitivity;
    table_to_write_to.specificity(row_to_write_to) = specificity;
    table_to_write_to.AUC(row_to_write_to) = auc;
    ResultTable =  table_to_write_to;
end