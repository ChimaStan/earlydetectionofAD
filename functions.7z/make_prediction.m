% predicts outcome and measures accuracy
function [y_pred, pred_scores,accuracy] = make_prediction(trained_model,X_test,y_test)
[y_pred, pred_scores] = predict(trained_model,X_test);
accuracy = 1-loss(trained_model,X_test,y_test, 'LossFun', 'ClassifError');
accuracy = accuracy*100;
end


