% write file to csv
function write_table_to_csv(table,model_name,panel_categ)
fileName = strcat('panel_size_',num2str(panel_categ),model_name,'.csv');
writetable(table,fileName)
